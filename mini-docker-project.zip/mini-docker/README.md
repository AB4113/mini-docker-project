# Mini-Docker Container Engine
**Developed by:** Abenezer Beyene

A low-level toy container engine written in Rust using Linux namespaces (`CLONE_NEWPID`, `CLONE_NEWNET`, `CLONE_NEWNS`, `CLONE_NEWIPC`, `CLONE_NEWUTS`) and `pivot_root` for complete process containment.

## Structure
- `Cargo.toml`: Package configuration and low-level `nix` crate dependencies.
- `src/main.rs`: Core multi-stage runtime implementing cloning logic and file system isolation pivots.

## Prerequisites
- Linux Environment (Native Kernel or WSL2)
- Root Privileges (`sudo`)

## Quickstart
```bash
cargo build --release
sudo ./target/release/mini-docker run --rootfs /path/to/your/rootfs /bin/sh
```
