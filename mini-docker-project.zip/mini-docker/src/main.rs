/// ======================================================================
/// MINI-DOCKER: TOY CONTAINER ENGINE
/// Developed by: Abenezer Beyene
/// ======================================================================
/// This binary acts as both the supervisor (parent) and the containerized
/// init process (child). It uses Linux namespaces and pivot_root to isolate
/// execution environments.
/// 
/// Note: Must be run as root (sudo) on a Linux host/WSL2 ecosystem.

use clap::{Parser, Subcommand};
use nix::mount::{mount, umount2, MntFlags, MsFlags};
use nix::sched::{clone, CloneFlags};
use nix::sys::signal::Signal;
use nix::unistd::{chdir, execvp, getpid, pivot_root, Gid, Uid};
use std::ffi::CString;
use std::fs;
use std::path::Path;

#[derive(Parser)]
#[command(
    name = "mini-docker",
    author = "Abenezer Beyene",
    version = "1.0",
    about = "A low-level toy container engine written in Rust"
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Runs a command inside a new isolated container environment
    Run {
        /// Path to the isolated root filesystem directory (e.g., an uncompressed alpine rootfs)
        #[arg(long)]
        rootfs: String,

        /// Command to execute inside the container
        #[arg(last = true, required = true)]
        command: Vec<String>,
    },
    /// Internal command used by the engine to setup the child process execution context
    Child {
        #[arg(long)]
        rootfs: String,
        #[arg(last = true)]
        command: Vec<String>,
    },
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Run { rootfs, command } => {
            if !Uid::current().is_root() {
                eprintln!("Error: mini-docker must be executed with root/sudo privileges.");
                std::process::exit(1);
            }
            parent_init(&rootfs, command);
        }
        Commands::Child { rootfs, command } => {
            child_exec(&rootfs, command);
        }
    }
}

/// The Parent process initializes namespaces by spawning a copy of itself
/// using the `clone` system call with specific namespace flags.
fn parent_init(rootfs: &str, command: Vec<String>) {
    println!("[Parent] Spawning containerized child process via namespace isolation...");

    // Stack allocation for the cloned child process
    const STACK_SIZE: usize = 1024 * 1024; // 1MB Stack
    let mut stack = vec![0u8; STACK_SIZE];

    // Combine essential isolation namespaces
    let clone_flags = CloneFlags::CLONE_NEWPID   | // Isolated Process ID space (child becomes PID 1)
                      CloneFlags::CLONE_NEWNET   | // Isolated Network device layer
                      CloneFlags::CLONE_NEWNS    | // Isolated Mount spaces
                      CloneFlags::CLONE_NEWIPC   | // Isolated Inter-Process Communication
                      CloneFlags::CLONE_NEWUTS;    // Isolated Hostname/Domain configs

    // Prepare a closure that re-executes the binary under the 'child' subcommand context
    let child_callback = Box::new(|| -> isize {
        let current_exe = std::env::current_exe().expect("Failed to get current binary path");
        
        let mut args = vec![
            current_exe.to_str().unwrap().to_string(),
            "child".to_string(),
            "--rootfs".to_string(),
            rootfs.to_string(),
            "--".to_string(),
        ];
        args.extend(command.clone());

        let c_args: Vec<CString> = args.iter()
            .map(|arg| CString::new(arg.as_str()).unwrap())
            .collect();

        let c_executable = CString::new(current_exe.to_str().unwrap()).unwrap();
        
        // Re-exec into the child branch inside the isolated namespace boundary
        match execvp(&c_executable, &c_args) {
            Ok(_) => 0,
            Err(e) => {
                eprintln!("[Child Init Error]: Failure executing execvp: {}", e);
                -1
            }
        }
    });

    // Invoke the clone system call
    let child_pid = match clone(child_callback, &mut stack, clone_flags, Some(Signal::SIGCHLD as i32)) {
        Ok(pid) => pid,
        Err(e) => {
            eprintln!("Failed to clone process namespaces: {}", e);
            std::process::exit(1);
        }
    };

    println!("[Parent] Child container successfully provisioned with PID: {}", child_pid);
    
    // Await child process completion
    match nix::sys::wait::waitpid(child_pid, None) {
        Ok(status) => println!("[Parent] Container exited with status: {:?}", status),
        Err(e) => eprintln!("[Parent] Error waiting for container termination: {}", e),
    }
}

/// Executed within the freshly generated namespace layout. Responsible for filesystem containment.
fn child_exec(rootfs: &str, command: Vec<String>) {
    println!("[Child (PID {})] Setting up containment matrix...", getpid());

    // 1. Set hostname isolated inside UTS namespace boundary
    if let Err(e) = nix::unistd::sethostname("abenezer-container") {
        eprintln!("[Child Warn] Failed to declare isolated hostname: {}", e);
    }

    // 2. Prepare filesystems for pivot_root
    // pivot_root requires the new root to be a mount point. We bind-mount it to itself to satisfy this.
    let rootfs_path = Path::new(rootfs);
    mount(
        Some(rootfs_path),
        rootfs_path,
        None::<&str>,
        MsFlags::MS_BIND | MsFlags::MS_REC,
        None::<&str>,
    ).expect("Failed to bind mount rootfs directory to itself");

    // Establish an internal path for the old host root storage directory
    let old_root_dir = rootfs_path.join(".old_root");
    if !old_root_dir.exists() {
        fs::create_dir_all(&old_root_dir).expect("Failed to create temporary .old_root mountpoint");
    }

    // 3. Swap the root filesystem using pivot_root
    pivot_root(rootfs_path, &old_root_dir).expect("Failed to execute pivot_root system call");

    // Change current working directory to the new root
    chdir("/").expect("Failed to change working directory into isolated root path");

    // 4. Mount a fresh, isolated /proc so `ps` displays only the container's processes
    mount(
        Some("proc"),
        "/proc",
        Some("proc"),
        MsFlags::empty(),
        None::<&str>,
    ).expect("Failed to mount isolated /proc filesystem inside container");

    // 5. Unmount the old host filesystem layer to ensure strict containment breakout safety
    umount2("/.old_root", MntFlags::MNT_DETACH).expect("Failed to safely detach old root system layout");
    let _ = fs::remove_dir("/.old_root");

    // 6. Execute the user-specified payload command
    println!("[Child] Executing target command inside isolation: {:?}", command);
    let c_command = CString::new(command[0].as_str()).unwrap();
    let c_args: Vec<CString> = command.iter()
        .map(|arg| CString::new(arg.as_str()).unwrap())
        .collect();

    match execvp(&c_command, &c_args) {
        Ok(_) => {}
        Err(e) => {
            eprintln!("[Child Fatal] Command execution failure: {}", e);
            std::process::exit(1);
        }
    }
}
